En teoria esta todo bien lincado no faltan librerias ni nada.

- Descomprime la solucion en una carpeta vacia
- Entra en el directorio AA2 > PruebaSFML1
- Abre el archivo cbp
- Haz un Rebuild & Play
- Y Listo!

Como Jugar:
- Click izquierdo en los cuadrados de colores de al derecha para coger una comida de ese color
- Click izquierdo en el Circulo morado de la izquierda que tenga esa comida delante
- Si te has equivocado al coger una comida click Derecho y la tiras al suelo


NOTAS:
	En caso de que algo falle dinoslo y vete a nuestro git para descargarte la nueva version 		estara en la tag AA2BugSolved_X

GIT:  https://github.com/AbrahamArmasCordero/SFMLgame

Si tienes algun problema manda un correo a abraham.armas@enti.cat
